"""Standalone, hash-checked second-physical-CPU replication. Windows x64 only."""
import argparse,collections,csv,hashlib,json,pathlib,platform,random,statistics,time,sys
import numpy as np
from PIL import Image,__version__ as pillow_version
from charls_ctypes import CharLS
R=pathlib.Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,value):p.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf8')
def hardware(args):
 cpu=platform.processor()
 if sys.platform=='win32':
  import winreg
  with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,r'HARDWARE\DESCRIPTION\System\CentralProcessor\0') as k:
   cpu=winreg.QueryValueEx(k,'ProcessorNameString')[0].strip()
 return dict(cpu_brand_reported=cpu,os=platform.platform(),python=platform.python_version(),numpy=np.__version__,pillow=pillow_version,machine_label=args.machine_label,environment_user_declared=args.environment,limit='Reported brand/model and a VM label do not establish a second physical microarchitecture. Compare with the original host record.')
def main():
 ap=argparse.ArgumentParser()
 ap.add_argument('--check-only',action='store_true')
 ap.add_argument('--environment',choices=['unknown','baremetal','vm'],default='unknown')
 ap.add_argument('--machine-label',default='unlabelled')
 ap.add_argument('--repeats',type=int,default=9)
 ap.add_argument('--output',type=pathlib.Path)
 args=ap.parse_args();assert args.repeats>0
 out=args.output or R/'results'/time.strftime('%Y%m%d_%H%M%S');out.mkdir(parents=True,exist_ok=False)
 save(out/'hardware.json',hardware(args))
 binaries=json.loads((R/'binary_manifest.json').read_text(encoding='utf8'))
 for name,entry in binaries.items():assert sha(R/entry['file'])==entry['sha256'],('binary changed',name)
 models={name:CharLS(R/entry['file']) for name,entry in binaries.items()}
 assert len(models)==12, 'Expected all 12 frozen methods'
 sources=json.loads((R/'data_manifest.json').read_text(encoding='utf8'));assert len(sources)==18
 data=[]
 for source in sources:
  p=R/source['file'];assert sha(p)==source['sha256'],('input changed',source['name'])
  if source['group']=='kodak':
   for fmt,suffix in [('RGB','rgb'),('L','gray')]:
    data.append((source['name']+'_'+suffix,'kodak',np.asarray(Image.open(p).convert(fmt)).copy(),8))
  else:
   with Image.open(p) as im:
    assert im.n_frames=={'brain':10,'solidification':11}[source['group']]
    for i in range(im.n_frames):
     im.seek(i);a=np.asarray(im).copy();assert a.dtype==np.uint16
     data.append((source['name']+f'_{i:02d}',source['group'],a,16))
 assert len(data)==53 and collections.Counter(g for n,g,a,b in data)=={'kodak':32,'brain':10,'solidification':11}
 save(out/'protocol.json',dict(check_only=args.check_only,repeats=args.repeats,seed=20261102,methods=list(models),binary_manifest=binaries,input_manifest=sources,source_units='16 Kodak images and2 volumes; not53 independent sources',timing='ctypes encode/decode including buffer allocation/copy; matched variants within each compiler',cross_cpu_claim_requires='a genuinely different physical host; VM on same host only checks environment portability'))
 rng=random.Random(20261102);rows=[];checks=[]
 for name,group,a,bits in data:
  stream=models['clang_original'].encode(a,bits)
  for method,m in models.items():
   assert m.encode(a,bits)==stream,(name,method,'bytes')
   assert np.array_equal(m.decode(stream),a),(name,method,'pixels')
  checks.append(dict(input=name,group=group,shape=list(a.shape),bits=bits,pixels_sha256=sha_bytes(a.tobytes()),stream_sha256=sha_bytes(stream),all_exact=True))
  if not args.check_only:
   for rep in range(args.repeats):
    order=list(models);rng.shuffle(order)
    for method in order:
     t=time.perf_counter();s=models[method].encode(a,bits);et=time.perf_counter()-t
     assert s==stream
     t=time.perf_counter();rec=models[method].decode(stream);dt=time.perf_counter()-t
     assert np.array_equal(rec,a)
     rows.append(dict(input=name,source_group=group,method=method,repeat=rep,encode_seconds=et,decode_seconds=dt,bytes=len(stream)))
  save(out/'correctness.json',checks)
  if rows:
   with (out/'timings.csv').open('w',newline='',encoding='utf8') as f:
    w=csv.DictWriter(f,list(rows[0]));w.writeheader();w.writerows(rows)
  print(name,flush=True)
 result=dict(complete=True,check_only=args.check_only,all_exact=True,checks=len(checks),method_count=len(models),records=len(rows),physical_cpu_replication_not_automatically_certified=True,results={})
 if rows:
  for compiler in ['clang','msvc']:
   result['results'][compiler]={}
   for group in ['kodak','brain','solidification']:
    result['results'][compiler][group]={}
    for base in ['original','unroll','clz','binary','getterprevk']:
     result['results'][compiler][group][base]={}
     for phase in ['encode','decode']:
      gains=[]
      for name in sorted({r['input'] for r in rows if r['source_group']==group}):
       ts={k:statistics.median(r[phase+'_seconds'] for r in rows if r['input']==name and r['method']==compiler+'_'+k) for k in [base,'prevk']}
       gains.append(100*(1-ts['prevk']/ts[base]))
      result['results'][compiler][group][base][phase]=dict(median_time_reduction_pct=statistics.median(gains),wins=sum(x>0 for x in gains),n=len(gains),per_input=gains)
 save(out/'summary.json',result);print(json.dumps({k:v for k,v in result.items() if k!='results'},indent=2))
def sha_bytes(x):return hashlib.sha256(x).hexdigest()
if __name__=='__main__':main()
