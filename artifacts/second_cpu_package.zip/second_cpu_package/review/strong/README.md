# 强基线与机制对照构建

所有变体基于同一 CharLS 2.4.5 源码，只修改 `src/context_regular_mode.h`。本目录负责构建与短正确性核验，不报告性能。完整来源、SHA256、参数与每项核验见 `source_manifest.json`、`build_manifest.json`，源码差异见各 `.patch`。

|变体|用途|边界|
|---|---|---|
|unroll|GDCM 内嵌 CharLS 2018 固定提交中的 k=0…4 手展开，再从 5 搜索|保留 2.4.5 的 32 位计算与损坏数据 guard，不保存 k|
|clz|已公开 CharLS CLZ 思想回移至同一 host|uint32 CLZ 差和 int64 单步校正，不保存 k；这里统一 getter，不能当作整个 main 分支的复现|
|binary|同一单调谓词 `N·2^k≥A` 在合法 k 区间内二分求首真|int64 位宽与 candidate 相同；`max_k_value` 为 invalid sentinel；是 2024 二分搜索思想的 CPU 对照，不是 FPGA 资源/时序复现|
|getterprevk|保存旧 k，并在 getter 双向精确修正|同 candidate 的构造、字段顺序、布局、int64 位宽；只移动两条 while，并令 k_ mutable，隔离热启动与计算位置的增量|

unroll 与 CLZ 是已知方法；binary 是已知搜索思想的通用 CPU 对照；getterprevk 是机制消融。四者均不能用作本项目的独立创新宣称。

`getterprevk_vs_candidate.patch` 直接呈现计算位置对照。候选在更新统计之后计算，而 getterprevk 在下一次访问该 context 时计算；两者都必须保持原精确 k，而不是允许近似码率偏移。若 candidate 只胜过从零循环、却不胜过 getterprevk，则不能把更新处维护称为已证明的独立增量。

二分版本搜索边界直接沿用 host 的 `max_k_value=16`；它不是原文针对 8 位硬件的三级特化电路。因此只能回答通用二分 CPU 软件是否有竞争力。int64 与原 getter 的 int32 差异已显式记录，不能将差异都归因于搜索策略。对合法标准输入，本轮短验证要求输出字节与原版完全一致；它不穷尽损坏码流与整数未定义行为的差异。

编译采用与现有 original/prevk 对照相同的两套参数：Zig0.13.0/Clang `x86_64-windows-gnu -std=c++17 -O3 -DNDEBUG`，MSVC19.29 `x64 /MD /O2 /Ob2 /DNDEBUG /std:c++17`。绝对编译器间差异混有运行库/工具链因素，主比较应在同一编译器内进行。

运行 `build.ps1 -Compiler clang|msvc -Variant unroll|clz|binary|getterprevk` 可重建；`verify_build.py` 仅做 20 个小输入、12 DLL 的字节与交叉解码验证，没有计时或种子筛选。
