"""Prepare two mechanism controls without touching already compiled sources."""
import pathlib,shutil,re,json,hashlib,difflib
R=pathlib.Path(__file__).resolve().parent;B=R.parent.parent
src=next((B/'work/competitive_charls_current/source').iterdir())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=(src/'src/context_regular_mode.h').read_text(encoding='utf8')
pattern=r'    FORCE_INLINE int32_t get_golomb_coding_parameter\(\) const\n    \{.*?\n    \}'
matches=list(re.finditer(pattern,old,re.S));assert len(matches)==1
binary='''    FORCE_INLINE int32_t get_golomb_coding_parameter() const
    {
        // CPU control for the known monotone A/N threshold binary-search idea.
        // max_k_value is a sentinel for the host's invalid-data condition.
        int32_t lower{0};
        int32_t upper{max_k_value};
        while (lower < upper)
        {
            const int32_t middle{lower + (upper - lower) / 2};
            if ((static_cast<int64_t>(n_) << middle) >= a_)
                upper = middle;
            else
                lower = middle + 1;
        }
        if (UNLIKELY(lower == max_k_value))
            impl::throw_jpegls_error(jpegls_errc::invalid_encoded_data);
        return lower;
    }'''
binary_text=old[:matches[0].start()]+binary+old[matches[0].end():]
candidate=(B/'work/competitive_charls_current/prevk/src/context_regular_mode.h').read_text(encoding='utf8')
maintenance='''        // Exact incremental maintenance; preserve minimal n * 2^k >= a.
        while (k_ > 0 && (static_cast<int64_t>(n_) << (k_ - 1)) >= a_) --k_;
        while (k_ < max_k_value && (static_cast<int64_t>(n_) << k_) < a_) ++k_;
'''
assert candidate.count(maintenance)==1
getter_text=candidate.replace(maintenance,'')
start='''    FORCE_INLINE int32_t get_golomb_coding_parameter() const
    {
'''
assert getter_text.count(start)==1
getter_text=getter_text.replace(start,start+maintenance)
assert getter_text.count('    int32_t k_{};')==1
getter_text=getter_text.replace('    int32_t k_{};','    mutable int32_t k_{};')
records=json.loads((R/'source_manifest.json').read_text(encoding='utf8'))
for kind,changed in [('binary',binary_text),('getterprevk',getter_text)]:
 dest=R/kind
 if not dest.exists():shutil.copytree(src,dest)
 (dest/'src/context_regular_mode.h').write_text(changed,encoding='utf8')
 diffs=[str(p.relative_to(src)) for p in src.rglob('*') if p.is_file() and sha(p)!=sha(dest/p.relative_to(src))]
 assert len(diffs)==1 and diffs[0].replace('\\','/')=='src/context_regular_mode.h',diffs
 (R/(kind+'.patch')).write_text(''.join(difflib.unified_diff(old.splitlines(True),changed.splitlines(True),fromfile='original/context_regular_mode.h',tofile=kind+'/context_regular_mode.h')),encoding='utf8')
 records[kind]={'only_changed':diffs,'original_header_sha256':sha(src/'src/context_regular_mode.h'),'modified_header_sha256':sha(dest/'src/context_regular_mode.h'),'source_tag':'2.4.5'}
records['binary'].update(source_url='https://doi.org/10.1109/ACCESS.2024.3350344',implementation='CPU implementation of the known binary-search idea; not an FPGA reproduction',host_adaptations=['same monotone predicate over [0,max_k_value)','64bit shift matches candidate arithmetic width','max_k_value sentinel retains host invalid-data guard','no per-context state'])
records['getterprevk'].update(source_url='local:work/competitive_charls_current/prevk/src/context_regular_mode.h',implementation='mechanism ablation; warm-start from previous k with correction moved from update to getter',candidate_header_sha256=sha(B/'work/competitive_charls_current/prevk/src/context_regular_mode.h'),host_adaptations=['same constructor, member order, state size and int64 shifts as candidate','two exact while loops removed from update and inserted at getter entry','k_ mutable for const getter; no additional field','isolates computation timing, not a separately claimed new method'])
(R/'getterprevk_vs_candidate.patch').write_text(''.join(difflib.unified_diff(candidate.splitlines(True),getter_text.splitlines(True),fromfile='candidate/context_regular_mode.h',tofile='getterprevk/context_regular_mode.h')),encoding='utf8')
(R/'source_manifest.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf8')
print('prepared binary and getterprevk; only one changed file each')
