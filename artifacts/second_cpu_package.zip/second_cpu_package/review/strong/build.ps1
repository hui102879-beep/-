param([ValidateSet('unroll','clz','binary','getterprevk')][string]$Variant='unroll',[ValidateSet('clang','msvc')][string]$Compiler='clang')
$ErrorActionPreference='Stop'
$taskRoot=$PSScriptRoot
$workspaceRoot=(Resolve-Path (Join-Path $taskRoot '../..')).Path
$srcRoot=Join-Path $taskRoot $Variant
$buildRoot=Join-Path $taskRoot ('build/'+$Compiler+'_'+$Variant)
New-Item -ItemType Directory -Force $buildRoot | Out-Null
$dllPath=Join-Path $taskRoot ('build/charls_'+$Compiler+'_'+$Variant+'.dll')
if($Compiler -eq 'clang') {
 $zigPath=Join-Path $workspaceRoot 'work/competitive_host_vanilc/tools/ziglang/zig.exe'
 $env:ZIG_GLOBAL_CACHE_DIR=Join-Path $workspaceRoot 'work/competitive_charls/build/cache'
 $env:ZIG_LOCAL_CACHE_DIR=Join-Path $buildRoot 'localcache'
 $env:TEMP=Join-Path $buildRoot 'tmp';$env:TMP=$env:TEMP
 New-Item -ItemType Directory -Force $env:TEMP | Out-Null
 $cppFiles=Get-ChildItem -LiteralPath (Join-Path $srcRoot 'src') -Filter '*.cpp' | ForEach-Object FullName
 & $zigPath c++ -target x86_64-windows-gnu -std=c++17 -O3 -DNDEBUG -DCHARLS_LIBRARY_BUILD -I (Join-Path $srcRoot 'include') $cppFiles -shared -o $dllPath 2>&1 | Tee-Object (Join-Path $taskRoot ('build/'+$Compiler+'_'+$Variant+'.log'))
 if($LASTEXITCODE -ne 0){throw "Zig compile failed: $LASTEXITCODE"}
} else {
 $vcvars='D:\Program Files (x86)\Microsoft Visual Studio\2019\Community\VC\Auxiliary\Build\vcvars64.bat'
 $cpps=Get-ChildItem -LiteralPath (Join-Path $srcRoot 'src') -Filter '*.cpp' | ForEach-Object {'"'+$_.FullName+'"'}
 $lines=@('@echo off','chcp 65001 >nul',('call "'+$vcvars+'"'),('cd /d "'+$buildRoot+'"'),('cl.exe /nologo /LD /MD /O2 /Ob2 /DNDEBUG /DCHARLS_LIBRARY_BUILD /std:c++17 /EHsc /utf-8 /I"'+(Join-Path $srcRoot 'include')+'" '+($cpps -join ' ')+' /link /OUT:"'+$dllPath+'"'),'exit /b %errorlevel%')
 $batchPath=Join-Path $taskRoot ('build/compile_'+$Compiler+'_'+$Variant+'.cmd')
 [System.IO.File]::WriteAllLines($batchPath,$lines,[System.Text.UTF8Encoding]::new($false))
 & cmd.exe /d /c $batchPath 2>&1 | Tee-Object (Join-Path $taskRoot ('build/'+$Compiler+'_'+$Variant+'.log'))
 if($LASTEXITCODE -ne 0){throw "MSVC compile failed: $LASTEXITCODE"}
}
