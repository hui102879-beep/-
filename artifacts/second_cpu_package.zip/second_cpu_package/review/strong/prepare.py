"""Backport two known k computations; keep CharLS 2.4.5 statistics unchanged."""
import pathlib,shutil,re,json,hashlib,difflib
R=pathlib.Path(__file__).resolve().parent;B=R.parent.parent
src=next((B/'work/competitive_charls_current/source').iterdir())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=(src/'src/context_regular_mode.h').read_text(encoding='utf8')
pattern=r'    FORCE_INLINE int32_t get_golomb_coding_parameter\(\) const\n    \{.*?\n    \}'
matches=list(re.finditer(pattern,old,re.S));assert len(matches)==1
unroll='''    FORCE_INLINE int32_t get_golomb_coding_parameter() const
    {
        // Known hand-unrolled low-k tests from the GDCM-embedded CharLS GetGolomb.
        // Preserve the original 32-bit shifts and invalid-data guard of this host.
        const int32_t n_test{n_};
        const int32_t a_test{a_};
        if (n_test >= a_test) return 0;
        if ((n_test << 1) >= a_test) return 1;
        if ((n_test << 2) >= a_test) return 2;
        if ((n_test << 3) >= a_test) return 3;
        if ((n_test << 4) >= a_test) return 4;

        int32_t k{5};
        for (; (n_test << k) < a_test && k < max_k_value; ++k)
        {
        }
        if (UNLIKELY(k == max_k_value))
            impl::throw_jpegls_error(jpegls_errc::invalid_encoded_data);
        return k;
    }'''
clz_old=(B/'work/competitive_charls/variants/clz/src/context_regular_mode.h').read_text(encoding='utf8')
clz_match=list(re.finditer(pattern,clz_old,re.S));assert len(clz_match)==1
clz=clz_match[0].group(0)
records={}
for kind,func in [('unroll',unroll),('clz',clz)]:
 dest=R/kind
 if not dest.exists():shutil.copytree(src,dest)
 changed=old[:matches[0].start()]+func+old[matches[0].end():]
 (dest/'src/context_regular_mode.h').write_text(changed,encoding='utf8')
 diffs=[]
 for p in src.rglob('*'):
  if p.is_file() and sha(p)!=sha(dest/p.relative_to(src)):diffs.append(str(p.relative_to(src)))
 assert diffs==['src\\context_regular_mode.h'] or diffs==['src/context_regular_mode.h'],diffs
 (R/(kind+'.patch')).write_text(''.join(difflib.unified_diff(old.splitlines(True),changed.splitlines(True),fromfile='original/context_regular_mode.h',tofile=kind+'/context_regular_mode.h')),encoding='utf8')
 records[kind]={'only_changed':diffs,'original_header_sha256':sha(src/'src/context_regular_mode.h'),'modified_header_sha256':sha(dest/'src/context_regular_mode.h'),'source_tag':'2.4.5','implementation':'known method control, no state or model change'}
records['unroll']['source_url']='https://github.com/malaterre/GDCM/blob/35cf41f30ff9a13c430e5624ccd3c4956fba7df3/Utilities/gdcmcharls/context.h#L97'
records['unroll']['source_commit']='35cf41f30ff9a13c430e5624ccd3c4956fba7df3'
records['unroll']['source_snapshot_sha256']=sha(B/'work/robust_prior_art/source_snapshots/gdcm_context.h')
records['unroll']['host_adaptations']=['N/A renamed n_/a_','known early tests k0..4 preserved','fallback starts5','host max_k_value/invalid_encoded_data guard retained','32bit shifts match original getter']
records['clz']['source_url']='https://raw.githubusercontent.com/team-charls/charls/main/src/regular_mode_context.hpp'
records['clz']['host_adaptations']=['exact prior backport getter reused','host countl_zero helper; uint32 inputs','one correction uses int64 shift as prior CLZ control','no previous-k state']
(R/'source_manifest.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(records,ensure_ascii=False,indent=2))
