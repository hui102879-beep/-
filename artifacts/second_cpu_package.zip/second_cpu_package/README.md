# 第二台物理 CPU 复核包

Windows x64，Python 3.12（建议），仅依赖 NumPy、Pillow；ctypes 属于标准库。MSVC DLL 使用 /MD，机器需要已有兼容的 VC++ 2015–2022 x64 运行库。本包不安装系统组件。Clang 与 MSVC 原版、prevk、unroll、clz、binary、getterprevk 共12个冻结 DLL，读取前校验 SHA256。数据是16幅原尺寸 Kodak（RGB和灰度）及2份真实 uint16 体数据的全部21个切片，共53项表示。数据 URL/哈希在 data_manifest.json。

```powershell
python -m pip install -r requirements.txt
python run.py --check-only --environment baremetal --machine-label second-physical-host
python run.py --environment baremetal --machine-label second-physical-host
```

默认9次；随机顺序和所有输入固定。关闭其他编译/基准作业，使用稳定供电，并记录电源配置。输出在带时间戳的 results 子目录，包括硬件、协议、逐次 CSV、字节和像素校验、汇总；保留全部负结果。不得把重复次数、RGB/灰度表示或切片视为独立来源。比较在同一编译器内进行，Clang/MSVC 绝对差异混有编译参数和运行库因素。

在同一主机的虚拟机里可使用 `--environment vm` 检查运行环境正确性，但其性能结果只能描述该虚拟环境。虚拟机显示 Intel/另一代 AMD 名称不等于真实硬件变更；宿主 CPU、虚拟化调度、指令翻译均可能影响耗时。没有第二台真实物理机时，跨 CPU 实测应记为未完成。[QEMU CPU 模型文档](https://www.qemu.org/docs/master/system/qemu-cpu-models.html)说明 host-passthrough 和命名模型控制的是暴露给来宾的 CPU 模型/特性。

本机 check-only 只是包的正确性验证，不构成第二 CPU 复核。源码/许可证/补丁/编译信息在 review；新增控制在 review/strong。review/source 是 CharLS 2.4.5 原始源码，review/candidate 保存替换头文件，prevk.patch 给出差异。可用同一编译器的 C++17、Clang -O3 -DNDEBUG、MSVC /O2 /Ob2 /MD /DNDEBUG 重建；路径需按本机工具链调整。不要运行 update_binary_manifest.py 掩盖未经记录的二进制变化；重建后应作为另一组实验保存。

本实验优化软件编解码时间，码流/像素完全不变；不声称压缩率、核苷酸数或 DNA 通道恢复概率提高。53项表示仅来自18个源内容单元。

## 补充：远程云VM与CI的辅助复核（尚未运行）

上文关于同机VM的限制不等于否定不同宿主上的远程VM。远程Windows云VM运行本包时，应使用 `--environment vm` 并保留服务来源、实际来宾CPU信息、包哈希和完整结果，可以报告远程虚拟环境的外部复核。它不自动等同该型号CPU裸机，也不能只凭来宾品牌认证唯一物理宿主。GitHub每job创建新VM，仍不保证不同job来自不同物理宿主或CPU型号；公开Windows runner规格不承诺固定型号，参见[官方runner说明](https://docs.github.com/en/actions/reference/runners/github-hosted-runners)。

配套本地草案位于研究交付目录 `outputs/research_reframe`：`windows-remote-cpu.yml`、`run_remote_cpu.ps1`、`REMOTE_CI_README.md`。它们未上传、未运行；仅手动触发，先做正确性检查，benchmark固定12方法、53表示、9重复，保留所有负值。没有第二台机器也可以准备此辅助复核；型号可核实的实体机/云bare metal提供更直接的硬件证据。此补充没有更改DLL、测量代码或历史结果。
