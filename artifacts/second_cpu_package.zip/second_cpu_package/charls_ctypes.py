"""Small ctypes binding to official CharLS 2.4.5 C ABI."""
import ctypes as C
import pathlib
import numpy as np
class Frame(C.Structure):
    _fields_=[('width',C.c_uint32),('height',C.c_uint32),('bits',C.c_int32),('components',C.c_int32)]
class CharLS:
 def __init__(self,path):
  self.path=pathlib.Path(path).resolve();self.lib=C.CDLL(str(self.path));l=self.lib
  specs={
  'encoder_create':([],C.c_void_p),'encoder_destroy':([C.c_void_p],None),
  'encoder_set_frame_info':([C.c_void_p,C.POINTER(Frame)],C.c_int),
  'encoder_set_interleave_mode':([C.c_void_p,C.c_int],C.c_int),
  'encoder_set_near_lossless':([C.c_void_p,C.c_int],C.c_int),
  'encoder_get_estimated_destination_size':([C.c_void_p,C.POINTER(C.c_size_t)],C.c_int),
  'encoder_set_destination_buffer':([C.c_void_p,C.c_void_p,C.c_size_t],C.c_int),
  'encoder_encode_from_buffer':([C.c_void_p,C.c_void_p,C.c_size_t,C.c_uint32],C.c_int),
  'encoder_get_bytes_written':([C.c_void_p,C.POINTER(C.c_size_t)],C.c_int),
  'decoder_create':([],C.c_void_p),'decoder_destroy':([C.c_void_p],None),
  'decoder_set_source_buffer':([C.c_void_p,C.c_void_p,C.c_size_t],C.c_int),
  'decoder_read_header':([C.c_void_p],C.c_int),
  'decoder_get_frame_info':([C.c_void_p,C.POINTER(Frame)],C.c_int),
  'decoder_get_destination_size':([C.c_void_p,C.c_uint32,C.POINTER(C.c_size_t)],C.c_int),
  'decoder_decode_to_buffer':([C.c_void_p,C.c_void_p,C.c_size_t,C.c_uint32],C.c_int)}
  for n,(args,ret) in specs.items():
   f=getattr(l,'charls_jpegls_'+n);f.argtypes=args;f.restype=ret;setattr(self,n,f)
 def check(self,result):
  if result:raise RuntimeError('CharLS error '+str(result))
 def encode(self,a,bits=None):
  a=np.ascontiguousarray(a);h,w=a.shape[:2];comp=1 if a.ndim==2 else a.shape[2];bits=bits or a.dtype.itemsize*8
  enc=self.encoder_create();assert enc
  try:
   self.check(self.encoder_set_frame_info(enc,C.byref(Frame(w,h,bits,comp))))
   if comp>1:self.check(self.encoder_set_interleave_mode(enc,2))
   self.check(self.encoder_set_near_lossless(enc,0));sz=C.c_size_t()
   self.check(self.encoder_get_estimated_destination_size(enc,C.byref(sz)))
   # The API estimate is source bytes+1024, not a worst-case bound for random data.
   sz.value=max(sz.value,a.nbytes*2+8192);buf=C.create_string_buffer(sz.value)
   self.check(self.encoder_set_destination_buffer(enc,buf,sz.value))
   self.check(self.encoder_encode_from_buffer(enc,a.ctypes.data,a.nbytes,0))
   self.check(self.encoder_get_bytes_written(enc,C.byref(sz)))
   return buf.raw[:sz.value]
  finally:self.encoder_destroy(enc)
 def decode(self,raw):
  src=C.create_string_buffer(raw);dec=self.decoder_create();assert dec
  try:
   self.check(self.decoder_set_source_buffer(dec,src,len(raw)));self.check(self.decoder_read_header(dec));frame=Frame()
   self.check(self.decoder_get_frame_info(dec,C.byref(frame)));sz=C.c_size_t()
   self.check(self.decoder_get_destination_size(dec,0,C.byref(sz)));buf=C.create_string_buffer(sz.value)
   self.check(self.decoder_decode_to_buffer(dec,buf,sz.value,0));dtype=np.uint8 if frame.bits<=8 else np.uint16
   shape=(frame.height,frame.width) if frame.components==1 else (frame.height,frame.width,frame.components)
   return np.frombuffer(buf.raw,dtype=dtype).reshape(shape).copy()
  finally:self.decoder_destroy(dec)
