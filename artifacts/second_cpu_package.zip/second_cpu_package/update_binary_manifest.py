"""Rehash existing package DLLs; this changes the frozen input manifest.
Only use when deliberately rebuilding/replacing the reviewed binaries.
"""
import pathlib,hashlib,json
R=pathlib.Path(__file__).resolve().parent
entries={p.stem:{'file':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted((R/'bin').glob('*.dll'))}
assert len(entries)==12
(R/'binary_manifest.json').write_text(json.dumps(entries,indent=2),encoding='utf8')
print('MANIFEST',len(entries))
